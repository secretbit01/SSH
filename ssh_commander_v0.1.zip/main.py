import sys

from paramiko import SSHClient, SFTPClient
from PyQt6 import uic, QtWidgets

command = 'ls'  # Replace this command
command1 = 'cd Downloads&&cd'

cd_history = []

class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('main_ui.ui', self)

        self.client = SSHClient()

        self.connectButton.clicked.connect(self.connect)
        self.startButton.clicked.connect(self.start)
        self.stopButton.clicked.connect(self.stop)
        self.commandButton.clicked.connect(lambda: self.send(command))
        self.changeDirButton.clicked.connect(lambda: self.send(command1))

        self.show()

    def connect(self):
        print('Connecting...')
        self.client.load_system_host_keys()
        self.client.connect('93.104.211.241', username='root', password='KMsB87du')
        print('Connected.')

        self.startButton.setEnabled(True)
        self.stopButton.setEnabled(True)
        self.commandButton.setEnabled(True)
        self.changeDirButton.setEnabled(True)

    def start(self):
        stdin, stdout, stderr = self.client.exec_command('bash start_norma_arbitrage.sh norma.json')

        print(f'{stdout.read().decode("utf8")}')
        print(f'{stderr.read().decode("utf8")}')

    def stop(self):
        stdin, stdout, stderr = self.client.exec_command('bash stop_norma_arbitrage.sh norma.json')

        print(f'{stdout.read().decode("utf8")}')
        print(f'{stderr.read().decode("utf8")}')

    def cd(self, command):
        cd_history.append(command)

        stdin, stdout, stderr = self.client.exec_command(';'.join(cd_history))

        print(f'{stdout.read().decode("utf8")}')
        print(f'{stderr.read().decode("utf8")}')

        stdin.close()
        stdout.close()
        stderr.close()

    def send(self, command):
        stdin, stdout, stderr = self.client.exec_command(command)

        print(f'{stdout.read().decode("utf8")}')
        print(f'{stderr.read().decode("utf8")}')

        stdin.close()
        stdout.close()
        stderr.close()

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = Ui()
    app.exec()
